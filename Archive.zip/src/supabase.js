import { createClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL
const key = import.meta.env.VITE_SUPABASE_ANON_KEY

export const configMissing = !url || !key || url.includes('YOUR-PROJECT')
export const supabase = createClient(url || 'http://localhost', key || 'missing')
