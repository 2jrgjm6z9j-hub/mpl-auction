-- =====================================================================
-- STEP 4 (v3, final): Team Manager module migration
-- Safe to run more than once. Also safe if you already ran the older v1.
-- Paste ALL of this in Supabase > SQL Editor > New query > Run
-- =====================================================================

-- 1) Columns -----------------------------------------------------------
alter table auction_state add column if not exists last_result jsonb;

-- Manager email is stored in PROFILES (private: only the owner and admin
-- can read it). It must NOT be stored in TEAMS, because TEAMS is readable
-- by the public scoreboard.
alter table profiles add column if not exists email text;

do $$
begin
  if exists (select 1 from information_schema.columns
             where table_schema = 'public' and table_name = 'teams' and column_name = 'manager_email') then
    execute 'update profiles p set email = t.manager_email
               from teams t where t.user_id = p.id and p.email is null';
    execute 'alter table teams drop column manager_email';
  end if;
end $$;

-- one manager login per team
create unique index if not exists profiles_one_manager_per_team
  on profiles (team_id) where team_id is not null;

-- 2) Server clock (so every phone's countdown matches) -----------------
create or replace function server_time() returns timestamptz
language sql volatile as $$ select clock_timestamp() $$;
grant execute on function server_time() to anon, authenticated;

-- 3) place_bid (atomic; stale-purse race fixed) --------------------------
create or replace function place_bid(p_amount numeric)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_team teams; v_t tournaments; v_s auction_state; v_p players;
  v_count int; v_cat_count int; v_cat categories; v_need numeric;
  v_new_end timestamptz;
begin
  if p_amount is null or p_amount <= 0 then raise exception 'Invalid bid amount'; end if;

  select * into v_team from teams where id = my_team();
  if not found then raise exception 'This account is not linked to a team'; end if;
  select * into v_t from tournaments where id = v_team.tournament_id;

  -- ROW LOCK: simultaneous bids are processed one at a time, in order
  select * into v_s from auction_state where tournament_id = v_t.id for update;
  if not found or v_s.current_player_id is null then raise exception 'No player is on the block right now'; end if;

  -- re-read the team AFTER the lock so the purse figure can never be stale
  select * into v_team from teams where id = v_team.id for update;

  if v_s.status = 'paused' then raise exception 'Auction is paused'; end if;
  if v_s.status <> 'live' then raise exception 'Auction is not live'; end if;
  if v_s.timer_end is null or v_s.timer_end <= clock_timestamp() then raise exception 'Time is up for this player'; end if;
  if v_s.current_team_id = v_team.id then raise exception 'You already hold the highest bid'; end if;

  select * into v_p from players where id = v_s.current_player_id;

  if v_s.current_bid is null then
    if p_amount <> v_p.base_price then
      raise exception 'Opening bid must be the base price (%)', v_p.base_price;
    end if;
  else
    if not ((p_amount - v_s.current_bid) = any (v_t.bid_increments)) then
      raise exception 'Someone bid first. Current bid is now %', v_s.current_bid;
    end if;
  end if;

  select count(*) into v_count from purchases where team_id = v_team.id;
  if v_count >= v_t.max_squad then raise exception 'Your squad is full (% players)', v_t.max_squad; end if;

  select * into v_cat from categories where id = v_p.category_id;
  if found and v_cat.max_per_team is not null then
    select count(*) into v_cat_count from purchases pu
      join players pl on pl.id = pu.player_id
     where pu.team_id = v_team.id and pl.category_id = v_p.category_id;
    if v_cat_count >= v_cat.max_per_team then
      raise exception 'Category limit reached (max % %)', v_cat.max_per_team, v_cat.name;
    end if;
  end if;

  v_need := (v_t.max_squad - v_count - 1) * v_t.min_player_price;
  if v_team.purse - v_team.spent < p_amount + v_need then
    raise exception 'Not enough credits. You must keep % for your remaining slots', v_need;
  end if;

  v_new_end := clock_timestamp() + make_interval(secs => v_t.timer_reset_seconds);
  insert into bids (tournament_id, player_id, team_id, amount)
    values (v_t.id, v_p.id, v_team.id, p_amount);
  update auction_state set current_bid = p_amount, current_team_id = v_team.id,
         timer_end = greatest(v_new_end, timer_end), version = version + 1
   where tournament_id = v_t.id;

  return jsonb_build_object('ok', true, 'amount', p_amount);
end $$;

-- 4) start_player (guards added) ---------------------------------------
create or replace function start_player(p_tournament uuid, p_player uuid)
returns void language plpgsql security definer set search_path = public as $$
declare v_t tournaments; v_s auction_state; v_p players;
begin
  if not is_admin() then raise exception 'Admin only'; end if;
  select * into v_t from tournaments where id = p_tournament;
  select * into v_p from players where id = p_player and tournament_id = p_tournament;
  if not found then raise exception 'Player not found'; end if;
  if v_p.status in ('sold','live') then raise exception 'This player is already %', v_p.status; end if;
  if not v_p.available then raise exception 'This player is marked unavailable'; end if;

  insert into auction_state (tournament_id, status) values (p_tournament, 'idle')
    on conflict (tournament_id) do nothing;
  select * into v_s from auction_state where tournament_id = p_tournament for update;
  if v_s.current_player_id is not null then
    raise exception 'Finish or cancel the current player first';
  end if;

  update players set status = 'live' where id = p_player;
  if v_s.status = 'paused' then
    update auction_state set current_player_id = p_player, current_bid = null, current_team_id = null,
           timer_end = null, paused_remaining_ms = v_t.timer_seconds * 1000, version = version + 1
     where tournament_id = p_tournament;
  else
    update auction_state set status = 'live', current_player_id = p_player, current_bid = null,
           current_team_id = null, timer_end = clock_timestamp() + make_interval(secs => v_t.timer_seconds),
           paused_remaining_ms = null, version = version + 1
     where tournament_id = p_tournament;
  end if;
end $$;

-- 5) pause / resume (FIXED: the original could zero the timer if
--    "resume" was sent while already live, or "pause" while already paused)
create or replace function set_auction_paused(p_tournament uuid, p_pause boolean)
returns void language plpgsql security definer set search_path = public as $$
declare v_s auction_state;
begin
  if not is_admin() then raise exception 'Admin only'; end if;
  select * into v_s from auction_state where tournament_id = p_tournament for update;
  if not found then raise exception 'Auction has not been set up yet'; end if;

  if p_pause then
    if v_s.status <> 'live' then return; end if;      -- only a live auction can be paused
    update auction_state set status = 'paused',
      paused_remaining_ms = case when current_player_id is null or timer_end is null then null
        else greatest(0, floor(extract(epoch from (timer_end - clock_timestamp())) * 1000))::int end,
      version = version + 1
     where tournament_id = p_tournament;
  else
    if v_s.status <> 'paused' then return; end if;    -- only a paused auction can be resumed
    update auction_state set status = 'live',
      timer_end = case when current_player_id is null then null
        else clock_timestamp() + make_interval(secs => (coalesce(paused_remaining_ms, 0) / 1000.0)::float8) end,
      paused_remaining_ms = null, version = version + 1
     where tournament_id = p_tournament;
  end if;
end $$;

-- 6) finalize_current (sold / unsold) ----------------------------------
--    Admin: any time.  Anyone else: ONLY when the timer has really
--    expired AND there is a winning bid (and can never force UNSOLD).
create or replace function finalize_current(p_tournament uuid, p_force_unsold boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_s auction_state; v_p players; v_team teams; v_res jsonb; v_admin boolean := is_admin(); v_voided int := 0;
begin
  select * into v_s from auction_state where tournament_id = p_tournament for update;
  if not found or v_s.current_player_id is null then return jsonb_build_object('ok', false); end if;

  if not v_admin then
    p_force_unsold := false;
    if v_s.status <> 'live' or v_s.timer_end is null or v_s.timer_end > clock_timestamp()
       or v_s.current_team_id is null then
      return jsonb_build_object('ok', false);
    end if;
  end if;

  select * into v_p from players where id = v_s.current_player_id;

  if v_s.current_team_id is null or p_force_unsold then
    -- UNSOLD: nobody wins, so any bids for this player are cancelled (kept in the
    -- table with voided = true for the audit trail, hidden from the live bid list,
    -- and the player starts clean if re-auctioned later). Same transaction + same
    -- auction_state row lock as everything else, so it cannot race with a new bid.
    update bids set voided = true where player_id = v_p.id and voided = false;
    get diagnostics v_voided = row_count;
    update players set status = 'unsold' where id = v_p.id;
    v_res := jsonb_build_object('status','unsold','player_id',v_p.id,'player_name',v_p.full_name,
             'player_code',v_p.player_code,'photo_url',v_p.photo_url,'base_price',v_p.base_price,'at',now());
  else
    select * into v_team from teams where id = v_s.current_team_id for update;
    insert into purchases (tournament_id, player_id, team_id, price)
      values (p_tournament, v_p.id, v_team.id, v_s.current_bid);
    update teams set spent = spent + v_s.current_bid where id = v_team.id;
    update players set status = 'sold' where id = v_p.id;
    v_res := jsonb_build_object('status','sold','player_id',v_p.id,'player_name',v_p.full_name,
             'player_code',v_p.player_code,'photo_url',v_p.photo_url,'team_id',v_team.id,
             'team_name',v_team.name,'amount',v_s.current_bid,'at',now());
  end if;

  insert into audit_logs (tournament_id, actor, action, details)
    values (p_tournament, auth.uid(), 'finalize', v_res || jsonb_build_object('by_admin', v_admin, 'bids_voided', v_voided));

  update auction_state set current_player_id = null, current_bid = null, current_team_id = null,
         timer_end = null, paused_remaining_ms = null, last_result = v_res, version = version + 1
   where tournament_id = p_tournament;
  return jsonb_build_object('ok', true, 'result', v_res);
end $$;

-- 7) Admin helpers: reset timer, cancel bidding, skip -------------------
create or replace function reset_timer(p_tournament uuid)
returns void language plpgsql security definer set search_path = public as $$
declare v_t tournaments;
begin
  if not is_admin() then raise exception 'Admin only'; end if;
  select * into v_t from tournaments where id = p_tournament;
  update auction_state set
      timer_end = case when status = 'paused' then null else clock_timestamp() + make_interval(secs => v_t.timer_seconds) end,
      paused_remaining_ms = case when status = 'paused' then v_t.timer_seconds * 1000 else null end,
      version = version + 1
   where tournament_id = p_tournament and current_player_id is not null;
  insert into audit_logs (tournament_id, actor, action) values (p_tournament, auth.uid(), 'reset_timer');
end $$;

create or replace function cancel_bidding(p_tournament uuid)
returns void language plpgsql security definer set search_path = public as $$
declare v_s auction_state; v_t tournaments;
begin
  if not is_admin() then raise exception 'Admin only'; end if;
  select * into v_t from tournaments where id = p_tournament;
  select * into v_s from auction_state where tournament_id = p_tournament for update;
  if v_s.current_player_id is null then return; end if;
  update bids set voided = true where player_id = v_s.current_player_id and voided = false;
  update auction_state set current_bid = null, current_team_id = null,
      timer_end = case when status = 'paused' then null else clock_timestamp() + make_interval(secs => v_t.timer_seconds) end,
      paused_remaining_ms = case when status = 'paused' then v_t.timer_seconds * 1000 else null end,
      version = version + 1
   where tournament_id = p_tournament;
  insert into audit_logs (tournament_id, actor, action, details)
    values (p_tournament, auth.uid(), 'cancel_bidding', jsonb_build_object('player', v_s.current_player_id));
end $$;

create or replace function skip_current(p_tournament uuid)
returns void language plpgsql security definer set search_path = public as $$
declare v_s auction_state; v_p players;
begin
  if not is_admin() then raise exception 'Admin only'; end if;
  select * into v_s from auction_state where tournament_id = p_tournament for update;
  if v_s.current_player_id is null then return; end if;
  select * into v_p from players where id = v_s.current_player_id;
  update bids set voided = true where player_id = v_p.id and voided = false;
  update players set status = 'skipped' where id = v_p.id;
  update auction_state set current_player_id = null, current_bid = null, current_team_id = null,
      timer_end = null, paused_remaining_ms = null, version = version + 1,
      last_result = jsonb_build_object('status','skipped','player_id',v_p.id,'player_name',v_p.full_name,
                    'player_code',v_p.player_code,'photo_url',v_p.photo_url,'at',now())
   where tournament_id = p_tournament;
  insert into audit_logs (tournament_id, actor, action, details)
    values (p_tournament, auth.uid(), 'skip', jsonb_build_object('player', v_p.id));
end $$;

-- 8) Function permissions: only logged-in users may call these ---------
do $$
declare f text;
begin
  foreach f in array array[
    'place_bid(numeric)', 'start_player(uuid,uuid)', 'finalize_current(uuid,boolean)',
    'reset_timer(uuid)', 'cancel_bidding(uuid)', 'skip_current(uuid)',
    'set_auction_paused(uuid,boolean)'
  ] loop
    execute format('revoke execute on function %s from public, anon', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;
