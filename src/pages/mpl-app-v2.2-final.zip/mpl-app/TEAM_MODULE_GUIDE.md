# MPL Auction – Team Manager Module: iPhone Deployment Guide

Everything below can be done from an iPhone with Safari + the Files app. No computer, no paid service.
Tip: on Supabase, GitHub and Vercel, tap the **aA** icon in Safari → **Request Desktop Website**. Buttons are easier to find.

## What this update adds
- 8 separate manager logins (one per team). A manager sees only their own team dashboard.
- Manager **Live Auction** screen: player, base price, current bid, highest bidder, countdown, big BID button, SOLD / UNSOLD result.
- Every phone updates live (realtime + automatic 4-second safety refresh).
- Bids are processed one at a time in the database (row lock), so two teams can never create a conflicting result.
- Purse, 13-player limit, category limit and "keep enough credits for remaining slots" are enforced by the database, not only the screen.
- Admin: **Manager Logins** tab (create / change password / remove) and **Live Auction** tab (start player, pause, resume, reset timer, SOLD, UNSOLD, cancel bids, skip).
- Existing Admin features are untouched.

## Files in this update
| File | What to do | GitHub folder |
|---|---|---|
| `supabase/04_team_manager.sql` | Run in Supabase (Part 1) – not uploaded to GitHub | – |
| `api/manage-manager.js` | NEW | `api` (new folder) |
| `src/live.jsx` | NEW | `src` |
| `src/team.css` | NEW | `src` |
| `src/App.jsx` | REPLACE | `src` |
| `src/pages/Team.jsx` | NEW | `src/pages` |
| `src/pages/AuctionControl.jsx` | NEW | `src/pages` |
| `src/pages/Managers.jsx` | NEW | `src/pages` |

No new npm packages, so your Vercel build stays the same.

---------------------------------------------------------------
## PART 1 – Update the database (Supabase)

1. Open the ZIP in the **Files** app (tap it once → it unzips into a folder).
2. Open `supabase` → `04_team_manager.sql` → tap and hold the text → **Select All** → **Copy**.
3. Safari → supabase.com → your project → **SQL Editor** → **New query** → paste → **Run**.
   You should see "Success. No rows returned". It is safe to run twice, and it is also safe if you already ran an older version of this script (it migrates safely).
4. Check realtime is on: **Database → Publications → supabase_realtime**. The tables `auction_state`, `bids`, `purchases`, `teams` should be listed (they were added by the first script). If one is missing, run:
   `alter publication supabase_realtime add table auction_state, bids, purchases, teams;`

## PART 2 – Give Vercel the secret key (needed to create manager logins)

1. Supabase → **Project Settings → API** → find **service_role** (secret) → **Reveal** → **Copy**.
   ⚠️ This key is a master key. Never post it, never put it in GitHub or in the `.env` file.
2. Safari → vercel.com → your project → **Settings → Environment Variables**.
3. Name: `SUPABASE_SERVICE_ROLE_KEY` – Value: paste the key – tick Production, Preview, Development → **Save**.
4. Make sure `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` are already listed (they are from your first deployment).
5. Vercel redeploys when you commit code in Part 3. If you do Part 3 first, come back here and use **Deployments → ⋯ → Redeploy** after saving the key.

## PART 3 – Upload the new code (GitHub from iPhone)

Safari → github.com → your MPL repository.

**A. Files in `src/pages`** (Team.jsx, AuctionControl.jsx, Managers.jsx)
1. Tap folder `src` → tap folder `pages`.
2. **Add file → Upload files** → **Choose your files** → Browse → pick the 3 files from the unzipped folder `src/pages` (Files app) → **Commit changes**.

**B. Files in `src`** (live.jsx, team.css, App.jsx)
1. Go back to the repo, tap `src`.
2. **Add file → Upload files** → pick `live.jsx`, `team.css`, `App.jsx` (from unzipped `src`). Uploading App.jsx replaces the old one. **Commit changes**.

**C. The server function** (new folder `api`)
1. Repo main page → **Add file → Create new file**.
2. In the name box type exactly: `api/manage-manager.js` (typing the `/` creates the folder).
3. Open `api/manage-manager.js` in the Files app → Select All → Copy → paste into GitHub's editor → **Commit changes**.

**D. Wait for Vercel**: vercel.com → project → **Deployments**. Wait until the newest one says **Ready** (1–2 min). If it says **Error**, tap it → copy the red error text and send it to me.

If your repo has the project inside a sub-folder (for example `mpl-app/src/...`), do the same steps inside that sub-folder.

## PART 4 – Create the 8 manager logins

1. Open your Vercel website → log in as Admin.
2. Tab **👥 Manager Logins** → for each team tap **Create**.
3. Type the manager's email (their own email) → tap **Generate** for a password → **Create login**.
4. A "Login ready" box appears → **Share / Copy login details** → send via WhatsApp. The password is shown only once (you can set a new one anytime with the **Password** button).
5. Managers open the same website link, log in, and automatically land on their own team screen.

## PART 5 – Test (do these in order)

Use your iPhone as Admin and a second phone (or a private Safari tab) as a manager. Better: 2 managers on 2 phones.

1. Admin: Players tab has at least a few players with categories; Teams have logos.
2. Admin → **🎙️ Live Auction** → pick a player → **Start**.
3. Both managers instantly see the same player and a running countdown.
4. Manager 1 taps **BID** → both phones show the new bid, "HIGHEST BID" highlight, history entry.
5. Manager 2 bids → the highlight moves; timer resets to the "after each bid" seconds.
6. Let the timer reach 0 → player is **SOLD** automatically; everyone sees the SOLD card; credits are deducted on **My Team**.
7. Admin: start another player → **⏸ Pause** → managers' Bid button shows "Auction paused" → **▶ Resume**.
8. Admin: **❌ UNSOLD** on a player with no bids → managers see UNSOLD.
9. Refresh the page on any phone → everything is still there.
10. Try breaking rules: bid with 0 credits left, buy a 14th player, tap Bid on the same amount at the same time on 2 phones. You should get a friendly message and no wrong result.

## Troubleshooting
| Problem | Fix |
|---|---|
| "Server not configured" when creating a login | Part 2 not done, or you did not redeploy after adding the key |
| "The server function did not respond" | `api/manage-manager.js` not uploaded in the right place, or the Vercel deployment failed |
| "Email address is invalid" | Use a real-looking email address (e.g. name@gmail.com) |
| Manager sees "No team assigned" | The login was created but not linked – remove it on Manager Logins and create again |
| Manager sees "No access yet" | Account exists but has no role; admin must recreate it from Manager Logins |
| Nothing updates live | Check Part 1 step 4. The screen still refreshes every 4 seconds as a backup |
| "permission denied" / "function does not exist" | `04_team_manager.sql` not run, or failed – run it again and read the error |
| Bid button says "Not enough credits" | Rule: a team must keep (remaining slots − 1) × minimum price. Admin can lower the minimum on Setup & Rules |

## Honest notes
- I could not run this against your live Supabase from here, so please run the Part 5 test and send me screenshots of anything odd.
- All team purses/squads are readable by every logged-in manager and the public (the live bidding panel and public scoreboard need them). Managers can only **view** other teams; they cannot change anything. Only the database functions can change purses, bids and squads.
- Full Admin live console features (category rounds, shuffle order, unsold re-auction round, bid correction, reports) belong to the next module.
